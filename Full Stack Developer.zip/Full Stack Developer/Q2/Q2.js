function longestChainOfLetters() {
    const word = document.getElementById('word').value;
  
    let longestChain = 0;
    let currentChain = 0;
  
    for (let i = 0; i < word.length; i++) {
      if (word[i] === '1') {
        currentChain++;
      } else {
        longestChain = Math.max(longestChain, currentChain);
        currentChain = 0;
      }
    }
  
    longestChain = Math.max(longestChain, currentChain);
  
    document.getElementById('result').textContent = 'Length of the longest chain: ' + longestChain;
  }
  