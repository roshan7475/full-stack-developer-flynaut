const check1=document.getElementById("check1")
const check2=document.getElementById("check2")
const check3=document.getElementById("check3")

// for check condition 1 the result of the comparison "7" > 7

let condition1="7">7; // for storing result
check1.innerHTML=` "7">7 = ${condition1}`
console.log("7" > 7); // Output: false

// Output the result of the comparison "2" > "21"

let condition2="2">"21"; // for storing result
check2.innerHTML=` "2">"21" = ${condition2}`
console.log("2" > "21"); // Output: false

// Output the result of the comparison "KL" > "S"

let condition3= "KL">"S" // for storing result
check3.innerHTML=` "KL">"S" = ${condition3}`
console.log("KL" > "S"); // Output: false
